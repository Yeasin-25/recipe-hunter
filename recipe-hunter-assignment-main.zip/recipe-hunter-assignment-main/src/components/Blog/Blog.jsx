import React from 'react';

const Blog = () => {
    return (
        <div>
            blog
        </div>
    );
};

export default Blog;